---
title: "Golang 锁的实现"
date: 2021-05-13T10:48:28+08:00
draft: false
tags: ["golang"]
categories: ["golang"]
---

golang中，有一句话很是体现除了它的编程哲学，“不要用共享欸村来通信，而是通过通信来共享数据”。

在多线程的世界里面，常常需要多个线程共同访问同一个内存代码或者变量，也就是一个临界区，为此，需要给临界区上锁操作。通过加锁，释放锁来调节进出的线程。
在golang中，较为提倡的方式是通过通道channel,来进行多个协程之间的数据通讯，当然，golang 也是内置了锁的支持操作，也可以实现多线程访问临界区的方式。

    // 内置锁的结构体
    type Mutex struct {
        state int32             // 锁的状态
        sema  uint32            // 信号量
    }
   
    // 定义了锁的接口，需要有加锁和解锁操作。
    type Locker interface {
        Lock()
        Unlock()
    }

看锁定义的结构，可以看出，golang锁的实现也是基于信号量的，也即（二值信号量），信号量的值，非零既一。

来看看内置锁结构，Mutex的上锁方法Lock的实现

    func (m *Mutex) Lock() {
        // 使用cas方式进行加锁，将0修改成1
        if atomic.CompareAndSwapInt32(&m.state, 0, mutexLocked) {
            if race.Enabled {
                race.Acquire(unsafe.Pointer(m))
            }
            return
        }
        // Slow path (outlined so that the fast path can be inlined)
        // 如果加锁失败，进行自旋获取锁操作
        m.lockSlow()
    }

如果加锁失败，则调用 lockSlow 方法，加锁操作，使用cas方式进行加锁，cas是由硬件本身支持的原子性操作，防止因为系统时钟中断，导致了数据问题。

方法lockSlow的实现

    func (m *Mutex) lockSlow() {
        var waitStartTime int64
        starving := false
        awoke := false
        iter := 0
        old := m.state
        for {
            // Don't spin in starvation mode, ownership is handed off to waiters
            // so we won't be able to acquire the mutex anyway.
            // 1. 自旋操作
            if old&(mutexLocked|mutexStarving) == mutexLocked && runtime_canSpin(iter) {
                // Active spinning makes sense.
                // Try to set mutexWoken flag to inform Unlock
                // to not wake other blocked goroutines.
                if !awoke && old&mutexWoken == 0 && old>>mutexWaiterShift != 0 &&
                    atomic.CompareAndSwapInt32(&m.state, old, old|mutexWoken) {
                    awoke = true
                }
                runtime_doSpin()
                iter++
                old = m.state
                continue
            }
            // 更新锁相关的状态信息
            new := old
            // Don't try to acquire starving mutex, new arriving goroutines must queue.
            if old&mutexStarving == 0 {
                new |= mutexLocked
            }
            if old&(mutexLocked|mutexStarving) != 0 {
                new += 1 << mutexWaiterShift
            }
            // The current goroutine switches mutex to starvation mode.
            // But if the mutex is currently unlocked, don't do the switch.
            // Unlock expects that starving mutex has waiters, which will not
            // be true in this case.
            if starving && old&mutexLocked != 0 {
                new |= mutexStarving
            }
            if awoke {
                // The goroutine has been woken from sleep,
                // so we need to reset the flag in either case.
                if new&mutexWoken == 0 {
                    throw("sync: inconsistent mutex state")
                }
                new &^= mutexWoken
            }
            if atomic.CompareAndSwapInt32(&m.state, old, new) {
                if old&(mutexLocked|mutexStarving) == 0 {
                    break // locked the mutex with CAS
                }
                // If we were already waiting before, queue at the front of the queue.
                queueLifo := waitStartTime != 0
                if waitStartTime == 0 {
                    waitStartTime = runtime_nanotime()
                }
                // 使用信号量进行休眠
                runtime_SemacquireMutex(&m.sema, queueLifo, 1)
                starving = starving || runtime_nanotime()-waitStartTime > starvationThresholdNs
                old = m.state
                if old&mutexStarving != 0 {
                    // If this goroutine was woken and mutex is in starvation mode,
                    // ownership was handed off to us but mutex is in somewhat
                    // inconsistent state: mutexLocked is not set and we are still
                    // accounted as waiter. Fix that.
                    if old&(mutexLocked|mutexWoken) != 0 || old>>mutexWaiterShift == 0 {
                        throw("sync: inconsistent mutex state")
                    }
                    delta := int32(mutexLocked - 1<<mutexWaiterShift)
                    if !starving || old>>mutexWaiterShift == 1 {
                        // Exit starvation mode.
                        // Critical to do it here and consider wait time.
                        // Starvation mode is so inefficient, that two goroutines
                        // can go lock-step infinitely once they switch mutex
                        // to starvation mode.
                        delta -= mutexStarving
                    }
                    atomic.AddInt32(&m.state, delta)
                    break
                }
                awoke = true
                iter = 0
            } else {
                old = m.state
            }
        }
    
        if race.Enabled {
            race.Acquire(unsafe.Pointer(m))
        }
    }

