---
title: "Golang实现snowflake算法"
date: 2021-05-13T15:41:52+08:00
draft: false
tags: ["golang"]
categories: ["golang"]
---

在日常开发中，常常涉及到各种各样的id值，支付订单id,日志记录id,trace id等等，常见的分布式id生成方式也是有很多种的，比如数据库自增id,uuid，redis的整型id,还有snowflake算法生成的id等等.
下面来说明下，这几种常见的id生成方案。

### 1. 数据库自增id

这个是最容易想到的，日常开发中，基本上要跟数据库打各种交道，通过给数据表字段设置自增属性AUTO_INCREMENT来使数据库字段支持自增属性。

### 2. redis的incr,incrby命令

使用redis的话，可以通过incr,incrby命令等做值的自增操作，因为redis再处理命令的时候，是单进程的方式，


### 3. zookeeper


### 4. uuid规则


### 5. snowflake算法
