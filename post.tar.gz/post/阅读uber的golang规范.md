---
title: "阅读uber的golang规范"
date: 2021-04-29T10:26:00+08:00
draft: false
tags: ["golang"]
categories: ["golang"]
---

阅读uber的go规范，原文地址 https://github.com/uber-go/guide/blob/master/style.md


下面是一些我根据自己实际情况总结出来的，建议查看原文，根据自己的情况，看看是否也出现了类似的情况

#### 1. 第一条规则，也是uber的第一条规则，特别提出来。

    You almost never need a pointer to an interface. You should be passing interfaces as values，If you want interface methods to modify the underlying data, you must use a pointer.
    
翻译一下，就是对于接口类型，你绝大多数情况下不应该使用指针传递，而是使用值传递。除非你真的需要修改它的值。

#### 2. 在使用切片或者map这种底层包含真实数据结构的类型作为参数的时候，要注意。避免影响。

    func (d *Driver) SetTrips(trips []Trip) {
      // d.trips = trips
      d.trips = make([]Trip, len(trips))
      copy(d.trips, trips)
    }
    
    trips := ...
    d1.SetTrips(trips)
    
    // We can now modify trips[0] without affecting d1.trips.
    trips[0] = ...

比如上面的函数，参见的做法就是将使用注释的方式，但是当外部怼原来的前篇进行修改的时候，反而影响到了封装的函数，里面的赋的值。

### 3. defer函数的使用

虽然使用 defer 用于关闭资源，可能会有性能的开销，但是还是强烈建议大部分使用defer来关闭连接。针对于函数不止于一处返回的情况，同时defer还可以防止未关闭带来的内存泄露问题。


### 4. 使用"time"包来处理时间

golang使用time.Time来表示瞬时，用time.Duration来表示一段时间.

    // 错误的写法
    func isActive(now, start, stop int) bool {
      return start <= now && now < stop
    }
    // 正确的写法
    func isActive(now, start, stop time.Time) bool {
      return (start.Before(now) || start.Equal(now)) && now.Before(stop)
    }

使用time.Duration来处理一段时间区间的内容。

在我使用，gorm作为go的orm框架时候，在定义时间戳相关的字段上面，比如create_time,update_time等，会采用time.time等字段进行操作

    type Order struct {
        Id         int       `gorm:"column:id"`
        GoodsId    int       `gorm:"column:goods_id"`
        OrderId    string    `gorm:"column:order_id"`
        CreateTime time.Time `gorm:"column:create_time"`
        UpdateTime time.Time `gorm:"column:update_time"`
    }
    
当然，不仅限于gorm,其他的也是建议采用time包进行操作。列出了几种常用的，并且支持time时间的。

### 5. 错误类型和包装错误

在go 1.13版本之前的go中使用的错误信息相对来说比较简单，再后续的版本中，再错误的呈现上面有所增强。
尽量使用go内置的wrap包装类来判断是否包含指定错误，而不是之前用文本匹配等方式。

早期的方式

    if err.Error() == "could not open" {
      // handle
    } else {
       panic("unknown error")
    }
    
    if strings.Contains(err.Error(), "not found") {
      // handle
    } else {
       panic("unknown error")
    }

推荐写法

    if errors.Is(err, foo.ErrCouldNotOpen) {
        // handle
      } else {
        panic("unknown error")
      }

### 6. 要考虑断言失败的情况，这个会引起严重的panic, 同时panic默认，除了初始化失败以外，其他的不允许使用panic失败.而是以返回错误的方式。

### TODO 继续补充


