---
title: "Golang的垃圾回收"
date: 2021-05-28T17:48:53+08:00
draft: false
tags: ["golang"]
categories: ["golang"]
---

golang 采用的垃圾回收算法的策略是标记-清楚法
并且实现了三色标记法来减少 “STW” 所占用的时长

### 一. GC的流程

1.等待和确认上一次gc过程完成



















###二. GC的触发条件
* 申请内存
* 手动触发
* 后台定时触发

相关的触发条件判断

1.触发条件的判断

    func (t gcTrigger) test() bool {
        if !memstats.enablegc || panicking != 0 || gcphase != _GCoff {
            return false
        }
        switch t.kind {
        case gcTriggerHeap:		// 堆内存分配的大小达到粗触发GC的堆内存大小
            // Non-atomic access to heap_live for performance. If
            // we are going to trigger on this, this thread just
            // atomically wrote heap_live anyway and we'll see our
            // own write.
            return memstats.heap_live >= memstats.gc_trigger
        case gcTriggerTime:  // 达到指定的时间周期
            if gcpercent < 0 {
                return false
            }
            lastgc := int64(atomic.Load64(&memstats.last_gc_nanotime))
            return lastgc != 0 && t.now-lastgc > forcegcperiod
        case gcTriggerCycle:		// 触发新的一轮gc
            // t.n > work.cycles, but accounting for wraparound.
            return int32(t.n-work.cycles) > 0
        }
        return true
    }
    
2.go初始一个用户gc的后台任务

    func init() {
        // 调度器启动后台触发gc函数
        go forcegchelper()
    }
    
    func forcegchelper() {
        forcegc.g = getg()
        for {
            lock(&forcegc.lock)
            if forcegc.idle != 0 {
                throw("forcegc: phase error")
            }
            atomic.Store(&forcegc.idle, 1)
    
            // 为了避免持续消耗cpu资源 主动出让cpu
            goparkunlock(&forcegc.lock, waitReasonForceGGIdle, traceEvGoBlock, 1)
            // this goroutine is explicitly resumed by sysmon
            if debug.gctrace > 0 {
                println("GC forced")
            }
            // Time-triggered, fully concurrent.
            // 定时触发gc
            gcStart(gcTrigger{kind: gcTriggerTime, now: nanotime()})
        }
    }
    
这边说明一个gopark函数,在操作系统中，也是采用了park函数用来主动出让cpu资源,go这边类比，主动出让goroutine,让调度器调用其他的goroutine

3.手动进行GC

调用函数 

    // 同步阻塞进行gc
    runtime.GC()
    
    func GC() {
    
    	n := atomic.Load(&work.cycles)
    
    	// 等待上一次的标记和清除结束
    	gcWaitOnMark(n)
    
    	// 开启gc
    	gcStart(gcTrigger{kind: gcTriggerCycle, n: n + 1})
    
    	gcWaitOnMark(n + 1)
    
    	for atomic.Load(&work.cycles) == n+1 && sweepone() != ^uintptr(0) {
    		sweep.nbgsweep++
    		Gosched()
    	}
    
    	for atomic.Load(&work.cycles) == n+1 && atomic.Load(&mheap_.sweepers) != 0 {
    		Gosched()
    	}
    
    	mp := acquirem()
    	cycle := atomic.Load(&work.cycles)
    	if cycle == n+1 || (gcphase == _GCmark && cycle == n+2) {
    		mProf_PostSweep()
    	}
    	releasem(mp)
    }

3.系统分配内存的时候
