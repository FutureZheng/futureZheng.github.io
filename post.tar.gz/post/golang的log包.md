---
title: "Golang的Log包"
date: 2020-12-09T20:46:41+08:00
draft: false
tags: ["golang"]
categories: ["golang"]
---

# log包

### 1. 主要的包内结构体定义

<!--moer 这个是文章的摘要信息-->

标准包定义的结构体信息

    type Logger struct {
        // 原子锁
        mu     sync.Mutex // ensures atomic writes; protects the following fields
        prefix string     // prefix to write at beginning of each line
        flag   int        // properties
        out    io.Writer  // destination for output
        buf    []byte     // for accumulating text to write
    }

当前结构体包含了几个信息

* mu: 包内置的锁，针对一些常见设置操作，保证原子性。
* prefix：字段前缀，用于在写入日志前，加一个字段前缀信息。
* flag: 包内置了一些常用的时间输出格式，flag用来标识时间格式展示的类型.
* out: 输出设备信息。
* buf: 用于写入文件的日志内容信息。

### 2. 包内初始化的方法

包内初始化方法

    func New(out io.Writer, prefix string, flag int) *Logger {
        return &Logger{out: out, prefix: prefix, flag: flag}
    }


### 3. 包内置了一个开箱即用的标准log结构

初始化方法

    var std = New(os.Stderr, "", LstdFlags)

说明: LstdFlags为标准包内置定义的一种日志输出前缀格式，即时间 2006-01-02 15:04:05


常见的错误信息记录demo

    func Print(v ...interface{}) {
        std.Output(2, fmt.Sprint(v...))
    }

包内锁的使用

    func SetOutput(w io.Writer) {
        std.mu.Lock()
        defer std.mu.Unlock()
        std.out = w
    }
    
### 4. log包使用

main包调用

    package main

    import "log"

    func main() {
        log.Println("message")
    }


输出展示

    E:\goproject\study>go run main.go
    2020/11/06 20:34:34 message
