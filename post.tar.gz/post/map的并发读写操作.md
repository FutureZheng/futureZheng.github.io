---
title: "Map的并发读写操作"
categories: ["golang"]
tags: ["golang"]
date: 2021-04-27T12:01:41+08:00
draft: false
---

## golang map的并发读写问题

### 1.出现的问题

如果使用map出现这个情况的话，那可以肯定是并发读写map导致的了。

    fatal error: concurrent map read
     and map write

### 2.使用汇编查看go代码的执行情况

示例代码：

    func main()  {
    
        data := make(map[int]int, 0)
        var wg sync.WaitGroup
        wg.Add(2)
        go func() {
            defer wg.Done()
            for i:= 0; i < 50000000; i++ {
                data[i] = i
            }
        }()
    
        go func() {
            defer wg.Done()
            for i:= 0; i < 50000000; i++ {
                fmt.Println(data[i])
            }
        }()
    
        wg.Wait()
        fmt.Println("success")
    }

### 3.查看汇编代码执行的情况

    go tool compile -S main.go

执行的结果

    // 相关的汇编代码输出部分截图
	0x0066 00102 (main.go:32)	MOVQ	CX, (SP)
	0x006a 00106 (main.go:32)	PCDATA	$0, $3
	0x006a 00106 (main.go:32)	MOVQ	"".data(SB), DX
	0x0071 00113 (main.go:32)	PCDATA	$0, $0
	0x0071 00113 (main.go:32)	MOVQ	DX, 8(SP)
	0x0076 00118 (main.go:32)	MOVQ	AX, 16(SP)
	0x007b 00123 (main.go:32)	CALL	runtime.mapaccess1_fast64(SB)
	0x0080 00128 (main.go:32)	PCDATA	$0, $1
	0x0080 00128 (main.go:32)	MOVQ	24(SP), AX
	0x0085 00133 (main.go:32)	PCDATA	$0, $0
	0x0085 00133 (main.go:32)	MOVQ	(AX), AX
	0x0088 00136 (main.go:32)	MOVQ	AX, (SP)

其中留意到这句话。

    // 调用了runtime包的mapaccess1_fast64方法,访问元素
	0x007b 00123 (main.go:32)	CALL	runtime.mapaccess1_fast64(SB)

### 4.查看runtime.mapaccess1_fast64方法
    
    func mapaccess1_fast64(t *maptype, h *hmap, key uint64) unsafe.Pointer {
        if raceenabled && h != nil {
            callerpc := getcallerpc()
            racereadpc(unsafe.Pointer(h), callerpc, funcPC(mapaccess1_fast64))
        }
        if h == nil || h.count == 0 {
            return unsafe.Pointer(&zeroVal[0])
        }
        // 这边判断当前map是否是在进行写操作
        if h.flags&hashWriting != 0 {
            throw("concurrent map read and map write")
        }
        var b *bmap
        if h.B == 0 {
            // One-bucket table. No need to hash.
            b = (*bmap)(h.buckets)
        } else {
            hash := t.hasher(noescape(unsafe.Pointer(&key)), uintptr(h.hash0))
            m := bucketMask(h.B)
            b = (*bmap)(add(h.buckets, (hash&m)*uintptr(t.bucketsize)))
            if c := h.oldbuckets; c != nil {
                if !h.sameSizeGrow() {
                    // There used to be half as many buckets; mask down one more power of two.
                    m >>= 1
                }
                oldb := (*bmap)(add(c, (hash&m)*uintptr(t.bucketsize)))
                if !evacuated(oldb) {
                    b = oldb
                }
            }
        }
        for ; b != nil; b = b.overflow(t) {
            for i, k := uintptr(0), b.keys(); i < bucketCnt; i, k = i+1, add(k, 8) {
                if *(*uint64)(k) == key && !isEmpty(b.tophash[i]) {
                    return add(unsafe.Pointer(b), dataOffset+bucketCnt*8+i*uintptr(t.elemsize))
                }
            }
        }
        return unsafe.Pointer(&zeroVal[0])
    }

说明了原生的map不支持并发读写map的操作，会出现上面的问题。作为补充看一下map的写操作确认下

还是汇编查看了一下
    
    // 调用了runtime.mapassign_fast64方法
	0x0075 00117 (main.go:20)	CALL	runtime.mapassign_fast64(SB)
	
### 5. 查看该mapassign_fast64方法

    func mapassign_fast64ptr(t *maptype, h *hmap, key unsafe.Pointer) unsafe.Pointer {
        if h == nil {
            panic(plainError("assignment to entry in nil map"))
        }
        if raceenabled {
            callerpc := getcallerpc()
            racewritepc(unsafe.Pointer(h), callerpc, funcPC(mapassign_fast64))
        }
        // 判断是不是已经已经有map在写入了
        if h.flags&hashWriting != 0 {
            throw("concurrent map writes")
        }
        hash := t.hasher(noescape(unsafe.Pointer(&key)), uintptr(h.hash0))
    
        // Set hashWriting after calling t.hasher for consistency with mapassign.
        // 设置当前map的状态，为写入状态
        h.flags ^= hashWriting
    
        if h.buckets == nil {
            h.buckets = newobject(t.bucket) // newarray(t.bucket, 1)
        }
        
        // ....
    }

从上面看出来，在map做赋值操作的时候，会将当前map的状态设置为写入的状态。这样子在并发情况，另外的goroutine就没办法对当前map进行读取操作了.