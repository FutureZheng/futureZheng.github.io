---
title: "Golang的函数式编程"
date: 2021-04-16T15:17:44+08:00
draft: false
tags: ["golang"]
categories: ["golang"]
---

今天来聊一聊什么呢？golang的函数式编程吧.

如果你或多或少看过golang一些软件包的实现方式，就能大体看出端倪。

比如golang中，grpc客户端建立server的连接，使用的拨号函数.

    // 函数签名
    func Dial(target string, opts ...DialOption) (*ClientConn, error) {
    	return DialContext(context.Background(), target, opts...)
    }

通过上面的函数签名，可以看出，参数 target 为必填项，剩下的opts为可选参数，所以调用方在使用上，可以根据实际的需求传入的对应参数信息。
不仅如此，grpc还可以通过对外暴露一些相关options的方法，来作为配置可选项。比如下面的

    // 设置默认的通讯参数信息
    func WithDefaultCallOptions(cos ...CallOption) DialOption {
    	return newFuncDialOption(func(o *dialOptions) {
    		o.callOptions = append(o.callOptions, cos...)
    	})
    }
    
    // 设置最大的消息体大小
    func WithMaxMsgSize(s int) DialOption {
    	return WithDefaultCallOptions(MaxCallRecvMsgSize(s))
    }

诸如此类的方法.

    func DialContext(ctx context.Context, target string, opts ...DialOption) (conn *ClientConn, err error) {
        // ...
        
        // 执行对应的可选参数信息
        for _, opt := range opts {
            opt.apply(&cc.dopts)
        }
        
        // ....
    }

这样子对包的表现形式是无侵入式的，对于参数的配置不仅简洁优雅，而且扩展性好，只要增加相关的with系列函数，