---
title: "Redis-过期键删除策略"
date: 2021-05-07T17:19:57+08:00
draft: false
categories: ["redis"]
tags: ["redis"]
---

### redis的键删除策略

在使用redis的时候，基本上会给指定的缓存设置过期时间，让缓存自动过期。

总结了：
* 惰性删除。在查询的时候，如果key过期了，就进行删除操作。
* 定期删除。每经过一段时间，后台任务自动删除过期的数据。

#### 1. 惰性删除

文件: t_string.c文件

相关的代码分析
    
    // 公共的 get 函数
    int getGenericCommand(client *c) {
        robj *o;
    
        // 确认key是否可读，并回复
        if ((o = lookupKeyReadOrReply(c,c->argv[1],shared.null[c->resp])) == NULL)
            return C_OK;
    
        if (o->type != OBJ_STRING) {
            addReply(c,shared.wrongtypeerr);
            return C_ERR;
        } else {
            addReplyBulk(c,o);
            return C_OK;
        }
    }

通过 lookupKeyReadOrReply 函数，一路追踪下去，会观察到函数 lookupKeyReadWithFlags

    robj *lookupKeyReadWithFlags(redisDb *db, robj *key, int flags) {
        robj *val;
    
        // 判断key是否过期
        if (expireIfNeeded(db,key) == 1) {
            // 添加key过期的事件
            if (server.masterhost == NULL) {
                server.stat_keyspace_misses++;
                notifyKeyspaceEvent(NOTIFY_KEY_MISS, "keymiss", key, db->id);
                return NULL;
            }
    
            if (server.current_client &&
                server.current_client != server.master &&
                server.current_client->cmd &&
                server.current_client->cmd->flags & CMD_READONLY)
            {
                server.stat_keyspace_misses++;
                notifyKeyspaceEvent(NOTIFY_KEY_MISS, "keymiss", key, db->id);
                return NULL;
            }
        }
        val = lookupKey(db,key,flags);
        if (val == NULL) {
            server.stat_keyspace_misses++;
            notifyKeyspaceEvent(NOTIFY_KEY_MISS, "keymiss", key, db->id);
        }
        else
            // 添加命中key的数据统计
            server.stat_keyspace_hits++;
        return val;
    }
    
    // 判断key是否过期，过期就删除
    int expireIfNeeded(redisDb *db, robj *key) {
        if (!keyIsExpired(db,key)) return 0;
    
        /* If we are running in the context of a slave, instead of
         * evicting the expired key from the database, we return ASAP:
         * the slave key expiration is controlled by the master that will
         * send us synthesized DEL operations for expired keys.
         *
         * Still we try to return the right information to the caller,
         * that is, 0 if we think the key should be still valid, 1 if
         * we think the key is expired at this time. */
        if (server.masterhost != NULL) return 1;
    
        /* Delete the key */
        server.stat_expiredkeys++;
        propagateExpire(db,key,server.lazyfree_lazy_expire);
        notifyKeyspaceEvent(NOTIFY_EXPIRED,
            "expired",key,db->id);
        int retval = server.lazyfree_lazy_expire ? dbAsyncDelete(db,key) :
                                                   dbSyncDelete(db,key);
        if (retval) signalModifiedKey(NULL,db,key);
        return retval;
    }
    
    
#### 2. 定期删除
文件: redis.c文件
在启动redis server端的时候，server会启动特定的一些定时任务

    // 初始化server端的服务
    void initServer(void) {
        // ...
        // 创建服务端的定时任务
        /* Create the serverCron() time event, that's our main way to process
         * background operations. */
        if(aeCreateTimeEvent(server.el, 1, serverCron, NULL, NULL) == AE_ERR) {
            redisPanic("Can't create the serverCron time event.");
            exit(1);
        }
        // ...
    }

在数据库相关的定时任务当中,启用有一个 activeExpireCycle 函数

    void activeExpireCycle(int type) {
        /* This function has some global state in order to continue the work
         * incrementally across calls. */
        static unsigned int current_db = 0; /* Last DB tested. */
        static int timelimit_exit = 0;      /* Time limit hit in previous call? */
        static long long last_fast_cycle = 0; /* When last fast cycle ran. */
    
        int j, iteration = 0;
        int dbs_per_call = REDIS_DBCRON_DBS_PER_CALL;
        long long start = ustime(), timelimit;
    
        if (type == ACTIVE_EXPIRE_CYCLE_FAST) {
            if (!timelimit_exit) return;
            if (start < last_fast_cycle + ACTIVE_EXPIRE_CYCLE_FAST_DURATION*2) return;
            last_fast_cycle = start;
        }
    
        if (dbs_per_call > server.dbnum || timelimit_exit)
            dbs_per_call = server.dbnum;
    
        timelimit = 1000000*ACTIVE_EXPIRE_CYCLE_SLOW_TIME_PERC/server.hz/100;
        timelimit_exit = 0;
        if (timelimit <= 0) timelimit = 1;
    
        if (type == ACTIVE_EXPIRE_CYCLE_FAST)
            timelimit = ACTIVE_EXPIRE_CYCLE_FAST_DURATION; /* in microseconds. */
    
        for (j = 0; j < dbs_per_call; j++) {
            int expired;
            redisDb *db = server.db+(current_db % server.dbnum);
    
            current_db++;
    
            /* Continue to expire if at the end of the cycle more than 25%
             * of the keys were expired. */
            do {
                unsigned long num, slots;
                long long now, ttl_sum;
                int ttl_samples;
    
                /* If there is nothing to expire try next DB ASAP. */
                if ((num = dictSize(db->expires)) == 0) {
                    db->avg_ttl = 0;
                    break;
                }
                slots = dictSlots(db->expires);
                now = mstime();
    
                if (num && slots > DICT_HT_INITIAL_SIZE &&
                    (num*100/slots < 1)) break;
    
                expired = 0;
                ttl_sum = 0;
                ttl_samples = 0;
    
                if (num > ACTIVE_EXPIRE_CYCLE_LOOKUPS_PER_LOOP)
                    num = ACTIVE_EXPIRE_CYCLE_LOOKUPS_PER_LOOP;
    
                while (num--) {
                    dictEntry *de;
                    long long ttl;
    
                    // 删除过期的key
                    if ((de = dictGetRandomKey(db->expires)) == NULL) break;
                    ttl = dictGetSignedIntegerVal(de)-now;
                    if (activeExpireCycleTryExpire(db,de,now)) expired++;
                    if (ttl < 0) ttl = 0;
                    ttl_sum += ttl;
                    ttl_samples++;
                }
    
                /* Update the average TTL stats for this database. */
                if (ttl_samples) {
                    long long avg_ttl = ttl_sum/ttl_samples;
    
                    if (db->avg_ttl == 0) db->avg_ttl = avg_ttl;
                    /* Smooth the value averaging with the previous one. */
                    db->avg_ttl = (db->avg_ttl+avg_ttl)/2;
                }
    
                iteration++;
                if ((iteration & 0xf) == 0) { /* check once every 16 iterations. */
                    long long elapsed = ustime()-start;
    
                    latencyAddSampleIfNeeded("expire-cycle",elapsed/1000);
                    if (elapsed > timelimit) timelimit_exit = 1;
                }
                if (timelimit_exit) return;
            } while (expired > ACTIVE_EXPIRE_CYCLE_LOOKUPS_PER_LOOP/4);
        }
    }

