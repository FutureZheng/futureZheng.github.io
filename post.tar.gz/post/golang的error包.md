---
title: "Golang的Errors包"
date: 2021-01-30T10:29:04+08:00
draft: false
tags: ["golang"]
categories: ["golang"]
---

# errors包

### 1. 主要的包内结构体定义

标准包定义的结构体信息

    type errorString struct {
        s string
    }

内置一个错误信息的接口提，通过一个字符串来表示相关的错误信息

### 2. 包内初始化的方法

包内初始化方法

    func New(text string) error {
        return &errorString{text}
    }

通过对外暴露一个工厂方法，来初始化错误信息。

### 3. 使用方式


    func main()  {
        err := errors.New("This is a error ")
        fmt.Println(err)
    }

### 4. 使用上的弊端

说明：由于golang支持的错误信息，相对来说较为简单，只能返回一段字符串文本，无法表示出相关的调用信息，或者其他内容，常见的做法有两种

* 通过内置的fmt.Errorf来实现
* 通过自定义错误信息来返回

1.使用fmt.Errorf来实现

    func main()  {
        err := errors.New("This is a error ")
        err = fmt.Errorf("Wrap error: %v ", err)
        fmt.Println(err)
    }

问题点也相对明显，没办法拿到最原始的错误信息，因为使用了fmt.Errorf生成了新的error,并且拼接上新的错误信息。

2.自定义错误信息结构

    type MyErr struct {
        err error
        msg string
    }
    
    func (c MyErr)Error() string {
        return c.msg + c.err.Error()
    }
    
    func main()  {
        // 初始化错误信息
        err := errors.New("This is a error ")
    
        // 定义一层错误信息
        firstErr := &MyErr{err: err, msg: "First err "}
    
        // 定义第二层错误信息
        secondErr := &MyErr{err: firstErr, msg: "Second err "}
        fmt.Println(secondErr)
        fmt.Println(secondErr.err.Error())
    }
    

通多自定义错误的结构体信息，来实现多次错误信息的嵌套传递，但是，各个包，系统，业务邓定义的错误信息，不一定相互兼容，存在的各种差异，
golang 官方就实现了当前的错误包装

### 5. errors 的新特性

* 提供了包装类的错误信息
* 判断错误信息是否是再包装类李米娜
* 断言包装类的错误信息

1. 使用方式

通过扩展fmt.Errorf的标识符,%w来表示一个包装类的错误信息,来生成一个包装类的错误

    func main()  {
        err := errors.New("Invalid bad param ")
        newErr := fmt.Errorf("Wrap err: %w ", err)
        fmt.Println(newErr)
    }

源码分析

	var err error
	if p.wrappedErr == nil {
		err = errors.New(s)
	} else {
		err = &wrapError{s, p.wrappedErr}
	}
通过判断p.wrappedErr 是否存在，来确定，如果存在，表示这是一个包装类型，同事实例化一个内置的结构体wrapError

结构体说明

    type wrapError struct {
        msg string
        err error
    }
    
    func (e *wrapError) Error() string {
        return e.msg
    }
    
    func (e *wrapError) Unwrap() error {
        return e.err
    }
实现了解包的方法Unwrap,获取包装结构体内置的err类

工具类相关

1.Unwrap函数，用来获取包装错误类的错误信息

函数调用

    func main()  {
    
        newErr := fmt.Errorf("Wrap err: %w ", errors.New("Invalid bad param "))
        fmt.Println(errors.Unwrap(newErr))
    }

源码分析

    func Unwrap(err error) error {
        // 断言判断是否是包装类
        u, ok := err.(interface {
            Unwrap() error
        })
        // 判断是否是包装类
        if !ok {
            return nil
        }
        // 调用解包的方法
        return u.Unwrap()
    }
 
 说明：根据上面生成包装类和解包的方法来看，如果生成的是包装类，那一定是实现了Unwrap方法的结构体wrapError实例，这这边获取到对应内置错误信息.
 
2.Is函数，判断两个错误信息是否相等，或者包含关系
 
说明，再没有包装类的时候，判断两个错误信息是否相等，直接使用等号（=）来判断即可，err1 = err2 但是引入了包装类，要判断两个错误信息是否存在包含关系，就不能这样子判断了

函数调用

    func main()  {
    
        err := errors.New("Invalid bad param ")
        newErr := fmt.Errorf("Wrap err: %w ", err)
        fmt.Println(errors.Is(newErr, err))
    }
源码分析

    func Is(err, target error) bool {
        if target == nil {
            return err == target
        }
    
        isComparable := reflectlite.TypeOf(target).Comparable()
        for {
            // 判断两个错误信息是否相等
            if isComparable && err == target {
                return true
            }
            
            // 断言错误信息是否实现了IS函数，实际上就是判断是否是自定义实现了错误信息
            if x, ok := err.(interface{ Is(error) bool }); ok && x.Is(target) {
                return true
            }
            // TODO: consider supporting target.Is(err). This would allow
            // user-definable predicates, but also may allow for coping with sloppy
            // APIs, thereby making it easier to get away with them.
            
            // 解开一层包装类，获取错误信息
            if err = Unwrap(err); err == nil {
                return false
            }
        }
    }
 
 // TODO as函数