---
title: "Golang中的channel"
date: 2021-05-14T12:00:42+08:00
draft: false
tags: ["golang"]
categories: ["golang"]
---

channel 作为golang中用于goroutine之间的通讯的方式，经常会听到一句话，就是“不要通过共享内存来通信，而实通过通信来共享内存”。

总结一下：golang 是怎么处理发送数据到channel中的，。

今天就来好好聊一聊channel吧。

先来一个简单的使用例子:

    // 生产者的代码
	ch := make(chan int, 1)
	ch <- 1
	
使用汇编查看一下代码执行的运行时操作

	0x0038 00056 (main.go:4)	CALL	runtime.makechan(SB)        // 执行方法 makechan
	0x003d 00061 (main.go:4)	PCDATA	$0, $1
	0x003d 00061 (main.go:4)	MOVQ	16(SP), AX
	0x0042 00066 (main.go:5)	PCDATA	$0, $0
	0x0042 00066 (main.go:5)	MOVQ	AX, (SP)
	0x0046 00070 (main.go:5)	PCDATA	$0, $1
	0x0046 00070 (main.go:5)	LEAQ	""..stmp_0(SB), AX
	0x004d 00077 (main.go:5)	PCDATA	$0, $0
	0x004d 00077 (main.go:5)	MOVQ	AX, 8(SP)
	0x0052 00082 (main.go:5)	CALL	runtime.chansend1(SB)       // 执行方法，chansend1
	0x0057 00087 (main.go:7)	MOVQ	24(SP), BP
	0x005c 00092 (main.go:7)	ADDQ	$32, SP
	
#### 1. 先看看创建的channel的操作代码

func makechan(t *chantype, size int) *hchan {
	elem := t.elem

	// compiler checks this but be safe.
	if elem.size >= 1<<16 {
		throw("makechan: invalid channel element type")
	}
	if hchanSize%maxAlign != 0 || elem.align > maxAlign {
		throw("makechan: bad alignment")
	}

	mem, overflow := math.MulUintptr(elem.size, uintptr(size))
	if overflow || mem > maxAlloc-hchanSize || size < 0 {
		panic(plainError("makechan: size out of range"))
	}

    // 根据不同的情况，创建channel
	var c *hchan
	switch {
	case mem == 0:
		// 无缓冲队列
		c = (*hchan)(mallocgc(hchanSize, nil, true))
		// Race detector uses this location for synchronization.
		c.buf = c.raceaddr()
	case elem.ptrdata == 0:
		// Elements do not contain pointers.
		// Allocate hchan and buf in one call.
		c = (*hchan)(mallocgc(hchanSize+mem, nil, true))
		c.buf = add(unsafe.Pointer(c), hchanSize)
	default:
		// 元素包含指针
		c = new(hchan)
		c.buf = mallocgc(mem, elem, true)
	}

	c.elemsize = uint16(elem.size)
	c.elemtype = elem
	c.dataqsiz = uint(size)

	if debugChan {
		print("makechan: chan=", c, "; elemsize=", elem.size, "; dataqsiz=", size, "\n")
	}
	return c
}

上面的操作，就是一下参数检查，再根据实际情况，创建不同的hchan类型

源码定义的chan数据结构

    type hchan struct {
        qcount   uint           // total data in the queue
        dataqsiz uint           // size of the circular queue
        buf      unsafe.Pointer // points to an array of dataqsiz elements
        elemsize uint16
        closed   uint32         // 通道关闭的标识
        elemtype *_type // element type
        sendx    uint   // send index
        recvx    uint   // receive index
        recvq    waitq  // list of recv waiters
        sendq    waitq  // list of send waiters
    
        // 锁，用于保护结构体中的字段
        lock mutex
    }
 
相关的字段说明：

* qcount： 队列中的数据数量.
* dataqsiz: 循环队列的大小.
* bug: 指向缓冲区的数据指针.
* sendx：生产者获取循环队列里面的下标位置.
* recvx：消费者获取循环队列的数据下标.
* recvq：等待消费的goroutine列表
* sendq：等待发送的goroutine列表
* lock： hchan内置的锁，用于保护其余字段

#### 2. 看看发送数据的操作做了什么

    func chansend(c *hchan, ep unsafe.Pointer, block bool, callerpc uintptr) bool {
        if c == nil {
            if !block {
                return false
            }
            gopark(nil, nil, waitReasonChanSendNilChan, traceEvGoStop, 2)
            throw("unreachable")
        }
    
        if debugChan {
            print("chansend: chan=", c, "\n")
        }
    
        if raceenabled {
            racereadpc(c.raceaddr(), callerpc, funcPC(chansend))
        }
    
        if !block && c.closed == 0 && ((c.dataqsiz == 0 && c.recvq.first == nil) ||
            (c.dataqsiz > 0 && c.qcount == c.dataqsiz)) {
            return false
        }
    
        var t0 int64
        if blockprofilerate > 0 {
            t0 = cputicks()
        }
    
        // 加锁操作
        lock(&c.lock)
    
        // 如果当前发送的通道已经关闭，又发送了数据，这边会抛异常。
        if c.closed != 0 {
            unlock(&c.lock)
            panic(plainError("send on closed channel"))
        }
    
        // 有等待接收数据的goroutine列表
        if sg := c.recvq.dequeue(); sg != nil {
            // Found a waiting receiver. We pass the value we want to send
            // directly to the receiver, bypassing the channel buffer (if any).
            send(c, sg, ep, func() { unlock(&c.lock) }, 3)
            return true
        }
    
        // 元素的个数小于循环队列的大小,标识当前channe还可以存放数据
        if c.qcount < c.dataqsiz {
            qp := chanbuf(c, c.sendx)
            if raceenabled {
                raceacquire(qp)
                racerelease(qp)
            }
            typedmemmove(c.elemtype, qp, ep)
            c.sendx++
            if c.sendx == c.dataqsiz {
                c.sendx = 0
            }
            c.qcount++
            unlock(&c.lock)
            return true
        }
    
        if !block {
            unlock(&c.lock)
            return false
        }
    
        // Block on the channel. Some receiver will complete our operation for us.
        gp := getg()
        mysg := acquireSudog()
        mysg.releasetime = 0
        if t0 != 0 {
            mysg.releasetime = -1
        }
        mysg.elem = ep
        mysg.waitlink = nil
        mysg.g = gp
        mysg.isSelect = false
        mysg.c = c
        gp.waiting = mysg
        gp.param = nil
        c.sendq.enqueue(mysg)
        atomic.Store8(&gp.parkingOnChan, 1)
        // goroutine 告知调度器，讲当前goroutine进行休眠,让其他goroutine执行        
        gopark(chanparkcommit, unsafe.Pointer(&c.lock), waitReasonChanSend, traceEvGoBlockSend, 2)
        
        // 下面这部分代码为，调度器唤醒goroutine以后执行的代码数据
        KeepAlive(ep)
    
        // someone woke us up.
        if mysg != gp.waiting {
            throw("G waiting list is corrupted")
        }
        gp.waiting = nil
        gp.activeStackChans = false
        if gp.param == nil {
            if c.closed == 0 {
                throw("chansend: spurious wakeup")
            }
            panic(plainError("send on closed channel"))
        }
        gp.param = nil
        if mysg.releasetime > 0 {
            blockevent(mysg.releasetime-t0, 2)
        }
        mysg.c = nil
        releaseSudog(mysg)
        return true
    }

golang中向channel发送数据总结：

1. 如果当前channel存在消费者的goroutine列表,会将数据直接发放给第一个接收channel数据的goroutine。
2. 如果channel添加了数据缓存区，并且缓冲区没满,会计算新的数据位置，并且保存起来。
3. 如果缓冲区已经满了，或者当前channel是无缓冲区的，会生成sudog结构，挂载在channel发送者列表当中，并且让调度器休眠当前goroutine。


#### 3. 接收数据


示例代码

	ch := make(chan int, 0)
	go func(ch chan int) {
		ch <- 1
	}(ch)
	<- ch
	close(ch)

先看下汇编执行的代码

	0x00bb 00187 (main.go:15)	MOVQ	"".ch+64(SP), AX
	0x00c0 00192 (main.go:15)	PCDATA	$0, $0
	0x00c0 00192 (main.go:15)	MOVQ	AX, (SP)
	0x00c4 00196 (main.go:15)	MOVQ	$0, 8(SP)
	0x00cd 00205 (main.go:15)	CALL	runtime.chanrecv1(SB)
	0x00d2 00210 (main.go:16)	PCDATA	$0, $1
	0x00d2 00210 (main.go:16)	PCDATA	$1, $0
	0x00d2 00210 (main.go:16)	MOVQ	"".ch+64(SP), AX
	0x00d7 00215 (main.go:16)	PCDATA	$0, $0

执行的方法函数 chanrecv1

func chanrecv(c *hchan, ep unsafe.Pointer, block bool) (selected, received bool) {
	// raceenabled: don't need to check ep, as it is always on the stack
	// or is new memory allocated by reflect.

	if debugChan {
		print("chanrecv: chan=", c, "\n")
	}

	if c == nil {
		if !block {
			return
		}
		gopark(nil, nil, waitReasonChanReceiveNilChan, traceEvGoStop, 2)
		throw("unreachable")
	}

	if !block && (c.dataqsiz == 0 && c.sendq.first == nil ||
		c.dataqsiz > 0 && atomic.Loaduint(&c.qcount) == 0) &&
		atomic.Load(&c.closed) == 0 {
		return
	}

	var t0 int64
	if blockprofilerate > 0 {
		t0 = cputicks()
	}

	lock(&c.lock)

	// 当前channel已经关闭，并且元素的个数 = 0
	if c.closed != 0 && c.qcount == 0 {
		if raceenabled {
			raceacquire(c.raceaddr())
		}
		unlock(&c.lock)
		if ep != nil {
			typedmemclr(c.elemtype, ep)
		}
		return true, false
	}

	// 如果存在等待的生成这goroutine的话，直接回复
	if sg := c.sendq.dequeue(); sg != nil {
	    // 这边唤醒生产者的goroutine
		recv(c, sg, ep, func() { unlock(&c.lock) }, 3)
		return true, true
	}

	// 存在缓冲数据
	if c.qcount > 0 {
		// Receive directly from queue
		qp := chanbuf(c, c.recvx)
		if raceenabled {
			raceacquire(qp)
			racerelease(qp)
		}
		if ep != nil {
			// 将数据直接赋值到 ep 里面
			typedmemmove(c.elemtype, ep, qp)
		}
		typedmemclr(c.elemtype, qp)
		c.recvx++
		if c.recvx == c.dataqsiz {
			c.recvx = 0
		}
		c.qcount--
		unlock(&c.lock)
		return true, true
	}

	if !block {
		unlock(&c.lock)
		return false, false
	}
	// 如果没有数据接收

	// no sender available: block on this channel.
	gp := getg()
	mysg := acquireSudog()
	mysg.releasetime = 0
	if t0 != 0 {
		mysg.releasetime = -1
	}
	// No stack splits between assigning elem and enqueuing mysg
	// on gp.waiting where copystack can find it.
	mysg.elem = ep
	mysg.waitlink = nil
	gp.waiting = mysg
	mysg.g = gp
	mysg.isSelect = false
	mysg.c = c
	gp.param = nil

	// 将当前goroutine添加到等待接收的goroutine列表里面
	c.recvq.enqueue(mysg)

	// 当前goroutine做休眠操作
	atomic.Store8(&gp.parkingOnChan, 1)
	gopark(chanparkcommit, unsafe.Pointer(&c.lock), waitReasonChanReceive, traceEvGoBlockRecv, 2)

	// someone woke us up
	if mysg != gp.waiting {
		throw("G waiting list is corrupted")
	}
	gp.waiting = nil
	gp.activeStackChans = false
	if mysg.releasetime > 0 {
		blockevent(mysg.releasetime-t0, 2)
	}
	closed := gp.param == nil
	gp.param = nil
	mysg.c = nil
	releaseSudog(mysg)
	return true, !closed
}

golang中的channel接收数据总结:

1. 如果当前channel里面存在，等待生产的goutine，则消费者goroutine会唤醒第一个阻塞的生产goroutine,并且接收数据。
2. 如果channel的数据缓冲区不为空，说明还有数据可以直接取，直接从缓冲区获取数据，并修改数据的长度等。
3. 如果缓冲区为空，获取当前channel是阻塞的，同样会声场sudog结构, 挂载再channel的阻塞等待消费列表里面，等待生产者唤醒调度程序调度。

#### 4. close关闭channel

汇编代码
    
	0x00d2 00210 (main.go:16)	MOVQ	"".ch+64(SP), AX
	0x00d7 00215 (main.go:16)	PCDATA	$0, $0
	0x00d7 00215 (main.go:16)	MOVQ	AX, (SP)
	0x00db 00219 (main.go:16)	CALL	runtime.closechan(SB)
	0x00e0 00224 (main.go:17)	MOVQ	88(SP), BP
	0x00e5 00229 (main.go:17)	ADDQ	$96, SP

执行的函数 closechan

func closechan(c *hchan) {
	if c == nil {
		panic(plainError("close of nil channel"))
	}

	lock(&c.lock)
	// 关闭已经关闭过的channel,会引起异常
	if c.closed != 0 {
		unlock(&c.lock)
		panic(plainError("close of closed channel"))
	}

	if raceenabled {
		callerpc := getcallerpc()
		racewritepc(c.raceaddr(), callerpc, funcPC(closechan))
		racerelease(c.raceaddr())
	}

	c.closed = 1

	var glist gList

	// release all readers
	// 关闭所有的消费者等待列表
	for {
		sg := c.recvq.dequeue()
		if sg == nil {
			break
		}
		if sg.elem != nil {
			typedmemclr(c.elemtype, sg.elem)
			sg.elem = nil
		}
		if sg.releasetime != 0 {
			sg.releasetime = cputicks()
		}
		gp := sg.g
		gp.param = nil
		if raceenabled {
			raceacquireg(gp, c.raceaddr())
		}
		glist.push(gp)
	}

	// release all writers (they will panic)
	// 释放等待的发送者列表
	for {
		sg := c.sendq.dequeue()
		if sg == nil {
			break
		}
		sg.elem = nil
		if sg.releasetime != 0 {
			sg.releasetime = cputicks()
		}
		gp := sg.g
		gp.param = nil
		if raceenabled {
			raceacquireg(gp, c.raceaddr())
		}
		glist.push(gp)
	}
	unlock(&c.lock)

	// Ready all Gs now that we've dropped the channel lock.
	for !glist.empty() {
		gp := glist.pop()
		gp.schedlink = 0
		goready(gp, 3)
	}
}

简单小结：就是释放当前channel俩面的两个等待队列列表
