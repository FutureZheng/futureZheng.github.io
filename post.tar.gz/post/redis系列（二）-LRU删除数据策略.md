---
title: "Redis-LRU删除数据策略"
date: 2021-05-08T09:36:06+08:00
draft: false
categories: ["redis"]
tags: ["redis"]
---

除了上一篇文章介绍的redis两种删除key的方式以外，针对内存已经占满的情况下，redis还有一种额外的方式，处理内存数据。


#### 1.内存相关的配置

在redis的配置文件当中，根内存相关的参数配置有下面的几个相关的参数信息

* maxmemory : 允许redis使用的最大内存数据,默认为0，表示不开启内存淘汰
* maxmemory-policy ： 内存淘汰的策略. 默认 noeviction
* maxmemory-samples： 随机采样的精度，// TODO   

#### 2.淘汰策略

* volatile-lru -> 从所有的过期key中，采用近似LRU进行淘汰
* allkeys-lru -> 对所有的key,采用近似的LRU淘汰策略
* volatile-lfu -> 从所有的过期key中，采用近似LFU进行淘汰
* allkeys-lfu -> 对所有的key,采用近似的LFU淘汰策略.
* volatile-random -> 从过期的key集合中，随机删除key.
* allkeys-random -> 所有的key随机淘汰.
* volatile-ttl -> 淘汰最近的即将过期的key
* noeviction -> 不淘汰内存，只是返回错误.

上述的方式，都是在配置中，可以选择的redis淘汰key的方式。

#### 3.LRU策略

LRU策略：是通过记录每一个对象的访问时间,根据访问时间来判断对象的使用情况，如果长时间未被访问的对象，就会被redis淘汰掉。

#### 4. redis的对象

在redis中，每一个数据库，都保存再一个 redisDb 结构中，每一个redis的key,value都是一个redisObject对象，保存在dict键空间当中，存在过期时间的key,会额外保存在expires当中

    typedef struct redisDb {
        dict *dict;                // 数据库的键空间
        dict *expires;              // 过期键的存放集合
        dict *blocking_keys;        /* Keys with clients waiting for data (BLPOP) */
        dict *ready_keys;           /* Blocked keys that received a PUSH */
        dict *watched_keys;         /* WATCHED keys for MULTI/EXEC CAS */
        struct evictionPoolEntry *eviction_pool;    /* Eviction pool of keys */
        int id;                     /* Database ID */
        long long avg_ttl;          /* Average TTL, just for stats */
    } redisDb;

在redis的对象中，保存着一个字段lru:REDIS_LRU_BITS,用来记录redis对象的最近访问时长。

    typedef struct redisObject {
        unsigned type:4;        // 对象的类型
        unsigned encoding:4;    // 对应类型的编码
        unsigned lru:REDIS_LRU_BITS; /* lru time (relative to server.lruclock) */       // lru time 
        int refcount;           // 引用计数回收内存
        void *ptr;
    } robj;

根据上面所述，redis在每一次访问对象的时候，都会去更新lru的时长，作为淘汰判断的依据。


#### 4. lru更新的代码

执行redis命令的时候，进行是否需要内存淘汰。

    // 根据是否设置maxmemory来确认是否要处理内存信息
    if (server.maxmemory) {
        int retval = freeMemoryIfNeeded();
        if ((c->cmd->flags & REDIS_CMD_DENYOOM) && retval == REDIS_ERR) {
            flagTransaction(c);
            addReply(c, shared.oomerr);
            return REDIS_OK;
        }
    }
    

访问redis的数据，以string为例
    
    // 还是上一篇的方法
    robj *lookupKeyReadWithFlags(redisDb *db, robj *key, int flags) {
        robj *val;
    
        if (expireIfNeeded(db,key) == 1) {
            /* Key expired. If we are in the context of a master, expireIfNeeded()
             * returns 0 only when the key does not exist at all, so it's safe
             * to return NULL ASAP. */
            if (server.masterhost == NULL) {
                server.stat_keyspace_misses++;
                notifyKeyspaceEvent(NOTIFY_KEY_MISS, "keymiss", key, db->id);
                return NULL;
            }

            if (server.current_client &&
                server.current_client != server.master &&
                server.current_client->cmd &&
                server.current_client->cmd->flags & CMD_READONLY)
            {
                server.stat_keyspace_misses++;
                notifyKeyspaceEvent(NOTIFY_KEY_MISS, "keymiss", key, db->id);
                return NULL;
            }
        }
        // 访问key,并且更新对象的lru时间
        val = lookupKey(db,key,flags);
        if (val == NULL) {
            server.stat_keyspace_misses++;
            notifyKeyspaceEvent(NOTIFY_KEY_MISS, "keymiss", key, db->id);
        }
        else
            server.stat_keyspace_hits++;
        return val;
    }

    // 访问key
    robj *lookupKey(redisDb *db, robj *key, int flags) {
        dictEntry *de = dictFind(db->dict,key->ptr);
        if (de) {
            robj *val = dictGetVal(de);
    
            /* Update the access time for the ageing algorithm.
             * Don't do it if we have a saving child, as this will trigger
             * a copy on write madness. */
             // 更新对象的访问时间lru
            if (!hasActiveChildProcess() && !(flags & LOOKUP_NOTOUCH)){
                if (server.maxmemory_policy & MAXMEMORY_FLAG_LFU) {
                    updateLFU(val);
                } else {
                    val->lru = LRU_CLOCK();
                }
            }
            return val;
        } else {
            return NULL;
        }
    }
    
    // TODO 释放内存