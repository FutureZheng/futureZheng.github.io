---
title: "Golang的defer实现"
date: 2021-05-13T15:42:12+08:00
draft: true
tags: ["golang"]
categories: ["golang"]
---

defer是golang提供的一种延迟调用的方式，比如常见的