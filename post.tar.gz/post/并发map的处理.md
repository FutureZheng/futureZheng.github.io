---
title: "并发map的处理"
date: 2021-04-28T11:00:52+08:00
draft: false
tags: ["golang"]
categories: ["golang"]
---

上一篇，讲到了多个goroutine对map的操作，导致了并发读写的问题。也就是说，golang原生自带的map不是并发安全的。那现在有一个问题，如果真的有场景或者需求需要多个goroutine来操作map,这个时候，应该要怎么处理map呢？

### 1. 可以很快的想到的是，通过加锁操作，允许同一个时刻有且仅有一个goroutine进行操作.

在原来的代码基础上，增加了互斥锁操作。

1. 互斥锁

示例程序一

    func main()  {
   
        var locker sync.Mutex
    
        data := make(map[int]int, 0)
        var wg sync.WaitGroup
        wg.Add(2)
        go func() {
            defer wg.Done()
            for i:= 0; i < 1000; i++ {
                locker.Lock()
                data[i] = i
                locker.Unlock()
            }
        }()
    
        go func() {
            defer wg.Done()
            for i:= 0; i < 5000; i++ {
                locker.Lock()
                fmt.Println(data[1])
                locker.Unlock()
            }
        }()
    
        wg.Wait()
        fmt.Println("success")
    }
    
上面就是我们加入锁操作以后，可以解决并发读写map的问题，但是还是不够好，如果某一个goroutine获得了互斥锁，那其他的goroutine就只能等待锁的释放了。如果在使用场景上，是读多写少，那加了互斥锁比较影响读取数据的性能。这个时候，我们可以考虑添加读写锁。

2. 读写锁

示例程序二

    func main()  {
        var (
            data = make(map[int]int, 0)
            locker sync.RWMutex
            wg sync.WaitGroup
        )
        wg.Add(3)
        write := func() {
            defer wg.Done()
            fmt.Println(fmt.Sprintf("write-------开始了"))
            locker.Lock()
            fmt.Println(fmt.Sprintf("write-------加锁成功"))
            data[0] = 1
            time.Sleep(1 * time.Second)
            locker.Unlock()
            fmt.Println(fmt.Sprintf("write-------释放锁"))
        }
    
        go write()
    
        read := func(i int) {
            defer wg.Done()
    
            fmt.Println(fmt.Sprintf("read---%d----开始了", i))
            locker.RLock()
            fmt.Println(fmt.Sprintf("read---%d----加锁成功", i))
            fmt.Println(data[0])
            time.Sleep(1 * time.Second)
            locker.RUnlock()
            fmt.Println(fmt.Sprintf("read---%d----释放锁", i))
        }
        for i:= 0; i < 2;i++ {
            go read(i)
        }
    
        wg.Wait()
        fmt.Println("success")
    }

输出结果分析

输出结果1

    F:\study>go run main.go
    write-------开始了
    write-------加锁成功
    read---1----开始了
    read---0----开始了
    write-------释放锁
    read---1----加锁成功
    1
    read---0----加锁成功
    1
    read---0----释放锁
    read---1----释放锁
    success
    
输出结果2
    
    F:\study>go run main.go
    read---1----开始了
    read---1----加锁成功
    0
    read---0----开始了
    read---0----加锁成功
    0
    write-------开始了
    read---1----释放锁
    read---0----释放锁
    write-------加锁成功
    write-------释放锁
    success
    
从上面看出来几点重要的信息。

1. 读写锁也能解决并发读写map的问题。
2. 如果某一个goroutine获得了写锁，那么其他的goroutine就没办法获取读锁和写锁了。
3. 如果某一个goroutine获取了读锁. 那么其他的goroutine没办法获得写锁，但是可以获取写锁。

|   |读锁|写锁|
|---|---|---|
|读锁| √ | X |
|写锁| X | X |

### 2. golang包提供了并发安全的map包，sync.map

示例程序三

    func main()  {
    
        data := new(sync.Map)
        var wg sync.WaitGroup
        wg.Add(2)
        go func() {
            defer wg.Done()
            for i:= 0; i < 1000; i++ {
                // 存储数据
                data.Store(1, i)
            }
        }()
    
        go func() {
            defer wg.Done()
            for i:= 0; i < 5000; i++ {
                // 读取数据
                fmt.Println(data.Load(1))
            }
        }()
    
        wg.Wait()
        fmt.Println("success")
    }

输出结果3

    999 true
    999 true
    999 true
    999 true
    999 true
    999 true
    999 true
    success

看输出结果，说明sync.map已经可以在并发的时候，安全的处理map的读写。